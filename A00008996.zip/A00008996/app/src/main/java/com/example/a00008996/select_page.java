package com.example.a00008996;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;

public class select_page extends AppCompatActivity {
    Spinner dropdown;
    Button addwordbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_page);
        dropdown = (Spinner)findViewById(R.id.spinner);
        addwordbtn = (Button)findViewById(R.id.button2);

        addwordbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String item = dropdown.getSelectedItem().toString();
                if(item.equals("English"))
                    startActivity(new Intent(dropdown.getContext(),english.class));
                if(item.equals("Russian"))
                    startActivity(new Intent(dropdown.getContext(),russian.class));
                if(item.equals("Uzbek"))
                    startActivity(new Intent(dropdown.getContext(),Uzbek.class));
            }
        });
    }

    public void word_list(View view) {
        Intent intent = new Intent(this, word_list.class);
        startActivity(intent);
    }

    public void exit(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        select_page.this.finish();
                        System.exit(0);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}
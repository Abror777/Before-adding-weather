package com.example.a00008996;
import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class english extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english);

    }

    public boolean back(View view) {
        this.finish();
        return true;
    }

    public void createWord(View view) {
        EditText etAddEnglish = findViewById(R.id.add_english);
        EditText etAddEnglishDesc = findViewById(R.id.add_english_desc);

        WordsDbHelper dbHelper = new WordsDbHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("word", etAddEnglish.getText().toString());
        values.put("description", etAddEnglishDesc.getText().toString());

        long id = db.insert("words", null, values);

        db.close();

        if (id>0){
            finish();
        }else{
            Toast.makeText(this, "There were an error ving your word", Toast.LENGTH_SHORT).show();
        }
    }
}
package com.example.a00008996;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class word_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word_list);
    }
}
package com.example.a00008996;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class WordsDbHelper extends SQLiteOpenHelper {
    public WordsDbHelper(@Nullable Context context) {
        super(context, "words.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE words(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, word TEXT NOT NULL, description TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
